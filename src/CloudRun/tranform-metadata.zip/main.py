import os
from flask import Flask, request
import logging
import pandas as pd
import gc
from functions_metadata import process_hours, process_categories, process_misc

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

@app.route("/", methods=["POST"])
def main():
    try:
        logging.info("Iniciando transformación...")

        # Leer rutas desde el request JSON
        data = request.get_json()
        input_path = data.get("input_path")
        output_path = data.get("output_path")

        if not input_path or not output_path:
            return "Faltan input_path o output_path en el request", 400

        logging.info(f"Usando input: {input_path}")
        logging.info(f"Usando output: {output_path}")

        # Leer datos desde GCS
        df_metadata = pd.read_parquet(input_path, engine="pyarrow")
        df_metadata = df_metadata.drop(columns=['relative_results', 'state'])

        # Categorías
        df_category, df_category_places = process_categories(df_metadata)
        df_category.to_parquet(f"{output_path}/gmap_category.parquet", engine="pyarrow", index=False)
        df_category_places.to_parquet(f"{output_path}/gmap_category_relacional.parquet", engine="pyarrow", index=False)
        del df_category, df_category_places
        df_metadata = df_metadata.drop(columns=['category'])
        gc.collect()

        # MISC
        df_attribute_types, df_attribute_values, df_relacional = process_misc(df_metadata)
        df_attribute_types.to_parquet(f"{output_path}/gmap_attribute_types.parquet", engine="pyarrow", index=False)
        df_attribute_values.to_parquet(f"{output_path}/gmap_attribute_values.parquet", engine="pyarrow", index=False)
        df_relacional.to_parquet(f"{output_path}/gmap_attribute_relacional.parquet", engine="pyarrow", index=False)
        del df_attribute_types, df_attribute_values, df_relacional
        df_metadata = df_metadata.drop(columns=['MISC'])
        gc.collect()

        # Hours
        df_hours = process_hours(df_metadata)
        df_hours.to_parquet(f"{output_path}/gmap_hours.parquet", engine="pyarrow", index=False)
        del df_hours
        df_metadata = df_metadata.drop(columns=['hours'])
        gc.collect()

        # Sitios
        df_metadata.to_parquet(f"{output_path}/gmaps_sites.parquet", engine="pyarrow", index=False)
        logging.info("Transformación completada correctamente.")
        return "Transformación completada correctamente", 200

    except Exception as e:
        logging.exception("Ocurrió un error en la función:")
        return f"Error: {str(e)}", 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)