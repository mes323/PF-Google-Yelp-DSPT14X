import pandas as pd
import ast
import numpy as np
import re

def process_categories(df):
    df_temp = df[['gmap_id', 'category']].copy()

    def convertir_a_lista(x):
        try:
            if x is None:
                return []
            if isinstance(x, (list, np.ndarray)):
                return list(x)
            if isinstance(x, str):
                try:
                    val = ast.literal_eval(x)
                    return val if isinstance(val, list) else [val]
                except:
                    return [x]
            return [x]
        except Exception:
            return []

    df_temp['category'] = df_temp['category'].apply(convertir_a_lista)
    df_temp = df_temp.explode('category')
    df_temp = df_temp[df_temp['category'].notna()]
    df_temp['category'] = df_temp['category'].astype(str).str.strip()
    df_temp = df_temp[df_temp['category'].str.lower() != 'nan']
    df_temp = df_temp[df_temp['category'] != '']

    df_temp['category'] = df_temp['category'].astype('category')
    df_categories = pd.DataFrame(df_temp['category'].cat.categories, columns=['category_name'])
    df_categories['category_id'] = df_categories.index + 1

    df_relacional = df_temp.merge(df_categories, left_on='category', right_on='category_name')
    df_gmap_category = df_relacional[['gmap_id', 'category_id']]

    return df_categories, df_gmap_category

def process_misc(metadata_df):
    rows = []
    for idx, row in metadata_df.iterrows():
        gmap_id = row["gmap_id"]
        misc = row["MISC"]

        if misc is None or (isinstance(misc, float) and np.isnan(misc)):
            continue

        if isinstance(misc, str):
            try:
                misc = ast.literal_eval(misc)
            except Exception:
                continue

        if not isinstance(misc, dict):
            continue

        for attr_type, attr_values in misc.items():
            if attr_values is None or (isinstance(attr_values, float) and np.isnan(attr_values)):
                continue

            if isinstance(attr_values, str):
                try:
                    attr_values = ast.literal_eval(attr_values)
                except Exception:
                    continue

            # Asegurarse de que sea iterable
            if not isinstance(attr_values, (list, set, tuple, np.ndarray)):
                attr_values = [attr_values]

            for val in attr_values:
                if val is None or (isinstance(val, float) and np.isnan(val)):
                    continue
                rows.append((gmap_id, attr_type, val))

    df_exploded = pd.DataFrame(rows, columns=["gmap_id", "attribute_type", "attribute_value"])

    # Eliminar duplicados por seguridad
    df_exploded = df_exploded.drop_duplicates()

    df_attribute_types = df_exploded[["attribute_type"]].drop_duplicates().reset_index(drop=True)
    df_attribute_types["attribute_type_id"] = df_attribute_types.index + 1
    df_exploded = df_exploded.merge(df_attribute_types, on="attribute_type", how="left")

    df_attribute_values = df_exploded[["attribute_value"]].drop_duplicates().reset_index(drop=True)
    df_attribute_values["attribute_value_id"] = df_attribute_values.index + 1

    df_relacional = df_exploded.merge(df_attribute_values, on="attribute_value", how="left")
    df_relacional = df_relacional[["gmap_id", "attribute_type_id", "attribute_value_id"]].drop_duplicates()

    return df_attribute_types, df_attribute_values, df_relacional

def estructurar_hours_debug(row):
    hours = row.get('hours')
    if hours is None or (isinstance(hours, float) and np.isnan(hours)) or (hasattr(hours, '__len__') and len(hours) == 0):
        return []

    resultado = []
    for val in hours:
        val = list(val) if hasattr(val, '__iter__') and not isinstance(val, str) else val
        if not val or len(val) != 2:
            continue

        day, time_str = val[0], val[1].strip().lower()
        if time_str == 'closed':
            continue
        if time_str == 'open 24 hours':
            resultado.append((day, '00:00', '23:59'))
            continue

        match = re.match(r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)[–-](\d{1,2})(?::(\d{2}))?\s*(am|pm)', time_str)
        if match:
            h1, m1, p1, h2, m2, p2 = match.groups()
            m1 = m1 or '00'
            m2 = m2 or '00'
            open_hour = (int(h1) % 12) + (12 if p1 == 'pm' else 0)
            close_hour = (int(h2) % 12) + (12 if p2 == 'pm' else 0)
            resultado.append((day, f"{open_hour:02d}:{m1}", f"{close_hour:02d}:{m2}"))

    return resultado

def process_hours(df):
    df['hours_parsed'] = df.apply(estructurar_hours_debug, axis=1)
    df_exploded = df.explode('hours_parsed').dropna(subset=['hours_parsed']).reset_index(drop=True)
    df_exploded[['days', 'open_time', 'close_time']] = pd.DataFrame(df_exploded['hours_parsed'].tolist(), index=df_exploded.index)

    df_exploded['open_time'] = pd.to_datetime(df_exploded['open_time'], format='%H:%M').dt.time
    df_exploded['close_time'] = pd.to_datetime(df_exploded['close_time'], format='%H:%M').dt.time

    df_grouped = (
        df_exploded
        .groupby(['gmap_id', 'open_time', 'close_time'])['days']
        .apply(lambda x: ', '.join(sorted(set(x))))
        .reset_index()
        .sort_values(by=['gmap_id', 'open_time'])
    )

    return df_grouped